import { initAuth, login, logout } from './core/auth.js';
import { initVentas } from './components/ui-ventas.js'; 
import { initInventario } from './components/ui-inventario.js';
import { initCaja } from './components/ui-caja.js'; 
import { initUsuarios, cargarUsuariosYLocales } from './components/ui-usuarios.js';
import { initPedidos } from './components/ui-pedidos.js'; 
import { initAnalisis } from './components/ui-analisis.js'; 
import { initRespaldo } from './components/ui-respaldo.js';
import { auth, onAuthStateChanged, db, doc, getDoc } from './core/firebase-setup.js';
import { state } from './core/store.js';

// ---- REGISTRO DEL SERVICE WORKER (Background Sync & Offline) ----
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('./sw.js')
            .then(registration => {
                console.log('ServiceWorker registrado con éxito con alcance:', registration.scope);

                // --- RADAR DE ACTUALIZACIONES (Modo Fantasma) ---
                // 1. Revisar cuando la app vuelve a ser visible (ej. al regresar de otra app o desbloquear)
                document.addEventListener('visibilitychange', () => {
                    if (document.visibilityState === 'visible') {
                        registration.update();
                    }
                });

                // 2. Revisar periódicamente cada 5 minutos en segundo plano
                setInterval(() => {
                    registration.update();
                }, 5 * 60 * 1000);
            })
            .catch(error => {
                console.error('El registro del ServiceWorker falló:', error);
            });

        // EL "EXPULSOR" (Modo Fantasma): Pantalla de Instalación tipo App Nativa
        // FIX: En la PRIMERA visita, clients.claim() también dispara 'controllerchange'.
        // Antes eso mostraba la pantalla "Instalando..." y recargaba la app a mitad
        // de la carga inicial (secciones a medio pintar). Ahora solo reaccionamos
        // cuando había un SW controlando previamente (actualización real).
        let refreshing = false;
        let habiaControlador = !!navigator.serviceWorker.controller;
        navigator.serviceWorker.addEventListener('controllerchange', () => {
            if (!habiaControlador) {
                // Primera instalación: el SW tomó control, pero NO es una actualización.
                habiaControlador = true;
                return;
            }
            if (!refreshing) {
                refreshing = true;
                
                // 1. Crear pantalla bloqueante de instalación
                const updateScreen = document.createElement('div');
                updateScreen.className = 'fixed inset-0 z-[9999] bg-slate-950 flex flex-col items-center justify-center text-white transition-opacity duration-300';
                updateScreen.innerHTML = `
                    <div class="flex flex-col items-center max-w-sm text-center px-6">
                        <i data-lucide="download-cloud" class="w-20 h-20 text-sky-500 mb-6 animate-bounce drop-shadow-[0_0_15px_rgba(14,165,233,0.5)]"></i>
                        <h2 class="text-2xl font-black mb-2">Instalando Actualización...</h2>
                        <p class="text-slate-400 text-sm mb-8 leading-relaxed">Por favor, no cierres la aplicación. Aplicando nuevas mejoras y optimizaciones del sistema en segundo plano.</p>
                        
                        <!-- Barra de progreso simulada -->
                        <div class="w-full h-2 bg-slate-800 rounded-full overflow-hidden shadow-inner">
                            <div class="h-full bg-sky-500 rounded-full animate-[progress_3s_ease-in-out_forwards] shadow-[0_0_10px_rgba(14,165,233,0.8)]" style="width: 0%;"></div>
                        </div>
                        <p class="text-[10px] text-slate-500 mt-4 uppercase font-bold tracking-widest">No apagues tu dispositivo</p>
                    </div>
                `;
                
                document.body.appendChild(updateScreen);
                if(window.lucide) window.lucide.createIcons();

                // 2. Inyectar animación de progreso temporal
                const style = document.createElement('style');
                style.textContent = '@keyframes progress { 0% { width: 0%; } 100% { width: 100%; } }';
                document.head.appendChild(style);

                // 3. Esperar 3 segundos (tiempo de la animación) y luego recargar forzosamente
                setTimeout(() => {
                    window.location.reload();
                }, 3000);
            }
        });
    });
}
// -----------------------------------------------------------------

// ---- LÓGICA DE PERFILES LOCALES (INICIO RÁPIDO) ----
function getSavedAccounts() {
    try { return JSON.parse(localStorage.getItem('icepos_accounts')) || []; } catch(e) { return []; }
}

function saveAccount(email, username, pass) {
    let accs = getSavedAccounts();
    const encodedPass = btoa(pass); 
    const existingIdx = accs.findIndex(a => a.email === email);
    
    if (existingIdx >= 0) {
        accs[existingIdx].pass = encodedPass;
        accs[existingIdx].username = username;
    } else {
        accs.push({ email, username, pass: encodedPass });
    }
    localStorage.setItem('icepos_accounts', JSON.stringify(accs));
}

function removeAccount(email) {
    let accs = getSavedAccounts();
    accs = accs.filter(a => a.email !== email);
    localStorage.setItem('icepos_accounts', JSON.stringify(accs));
    renderProfiles();
}

function renderProfiles() {
    const accs = getSavedAccounts();
    const profilesSec = document.getElementById('login-profiles-section');
    const manualSec = document.getElementById('login-manual-section');
    const list = document.getElementById('saved-profiles-list');
    const btnVolver = document.getElementById('btn-show-profiles');
    const subtitle = document.getElementById('login-subtitle');

    if (accs.length > 0) {
        if(subtitle) subtitle.textContent = "Selecciona tu cuenta";
        if(profilesSec) {
            profilesSec.classList.remove('hidden');
            profilesSec.classList.add('flex');
        }
        if(manualSec) manualSec.classList.add('hidden');
        if(btnVolver) btnVolver.classList.remove('hidden');

        if(list) {
            list.innerHTML = accs.map(a => `
                <div class="relative group">
                    <button data-action="quick-login" data-email="${a.email}" data-username="${a.username}" data-pass="${a.pass}" class="flex flex-col items-center gap-2 p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-sky-500 rounded-xl transition-all w-20 sm:w-24 active:scale-95 shadow-sm">
                        <div class="w-10 h-10 bg-sky-500 text-white rounded-full flex items-center justify-center shrink-0 shadow-md shadow-sky-500/30">
                            <i data-lucide="user" class="w-5 h-5"></i>
                        </div>
                        <span class="text-[10px] sm:text-xs font-bold text-slate-800 dark:text-white truncate w-full text-center capitalize">${a.username}</span>
                    </button>
                    <button data-action="remove-profile" data-email="${a.email}" class="absolute -top-1.5 -right-1.5 bg-red-500 hover:bg-red-600 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
                        <i data-lucide="x" class="w-3 h-3"></i>
                    </button>
                </div>
            `).join('');
        }
        if(window.lucide) window.lucide.createIcons();
    } else {
        if(subtitle) subtitle.textContent = "Punto de Venta Profesional";
        if(profilesSec) {
            profilesSec.classList.add('hidden');
            profilesSec.classList.remove('flex');
        }
        if(manualSec) manualSec.classList.remove('hidden');
        if(btnVolver) btnVolver.classList.add('hidden');
    }
}
// ---------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
    initAuth(); 
    let datosCargados = false;
    
    renderProfiles();

    document.getElementById('btn-show-manual-login')?.addEventListener('click', () => {
        document.getElementById('login-profiles-section').classList.add('hidden');
        document.getElementById('login-profiles-section').classList.remove('flex');
        document.getElementById('login-manual-section').classList.remove('hidden');
        if(document.getElementById('login-subtitle')) document.getElementById('login-subtitle').textContent = "Ingresa tus credenciales";
    });

    document.getElementById('btn-show-profiles')?.addEventListener('click', () => {
        renderProfiles(); 
    });

    // --- NUEVA LÓGICA: Alternar Visibilidad de Contraseña (Ojito) ---
    document.getElementById('btn-toggle-password')?.addEventListener('click', (e) => {
        const btn = e.currentTarget;
        const passInput = document.getElementById('login-password');
        
        if (passInput) {
            if (passInput.type === 'password') {
                passInput.type = 'text';
                btn.innerHTML = '<i data-lucide="eye-off" class="w-5 h-5 text-sky-400"></i>';
            } else {
                passInput.type = 'password';
                btn.innerHTML = '<i data-lucide="eye" class="w-5 h-5 text-slate-400"></i>';
            }
            if(window.lucide) window.lucide.createIcons();
        }
    });

    document.getElementById('saved-profiles-list')?.addEventListener('click', async (e) => {
        const btnLogin = e.target.closest('button[data-action="quick-login"]');
        const btnRemove = e.target.closest('button[data-action="remove-profile"]');

        if (btnRemove) {
            removeAccount(btnRemove.dataset.email);
            return;
        }

        if (btnLogin) {
            const email = btnLogin.dataset.email;
            const pass = atob(btnLogin.dataset.pass);
            
            const originalHtml = btnLogin.innerHTML;
            btnLogin.innerHTML = '<div class="w-10 h-10 flex items-center justify-center shrink-0"><i data-lucide="loader-2" class="w-6 h-6 animate-spin text-sky-500"></i></div><span class="text-xs font-bold text-sky-500 mt-2">Cargando...</span>';
            if(window.lucide) window.lucide.createIcons();
            
            try {
                await login(email, pass);
            } catch (err) {
                btnLogin.innerHTML = originalHtml;
                if(window.lucide) window.lucide.createIcons();
                
                if (err.message === "CUENTA_ELIMINADA" || err.message === "CUENTA_DESACTIVADA") {
                    removeAccount(email);
                    if(window.mostrarAlerta) window.mostrarAlerta('Acceso Denegado', 'Esta cuenta ha sido deshabilitada o eliminada permanentemente.', 'red');
                    setTimeout(() => location.reload(), 2000);
                } else {
                    if(window.mostrarAlerta) window.mostrarAlerta('Credenciales Caducadas', 'La contraseña fue cambiada. Inicia sesión manualmente.', 'amber');
                    removeAccount(email);
                }
            }
        }
    });

    // Escuchador del Estado de Autenticación
    onAuthStateChanged(auth, async (user) => {
        if (user && !datosCargados) {
            try {
                await new Promise(resolve => setTimeout(resolve, 300));

                await initUsuarios(); 
                await cargarUsuariosYLocales(); 
                
                initVentas(); 
                initPedidos(); 
                initRespaldo();
                initCaja(); 
                initAnalisis(); 
                
                await initInventario(); 
                if (typeof window.cargarInventarioDesdeFirebase === 'function') {
                    await window.cargarInventarioDesdeFirebase();
                }
                
                if (typeof window.renderProductosVenta === 'function') window.renderProductosVenta();
                if (typeof window.actualizarCarritoUI === 'function') window.actualizarCarritoUI();
                
                datosCargados = true;
            } catch(e) {
                console.error("Error inicializando componentes modulares:", e);
                datosCargados = true; 
            }
        } else if (!user) { 
            datosCargados = false; 
            renderProfiles();
        }
    });

    const lf = document.getElementById('login-form'); 
    const bs = document.getElementById('btn-submit-login');
    
    if (lf) {
        lf.addEventListener('submit', async (e) => {
            e.preventDefault(); 
            document.getElementById('login-error').classList.add('hidden');
            const ot = bs.innerHTML; 
            bs.innerHTML = '<i data-lucide="loader-2" class="w-5 h-5 animate-spin inline"></i> Conectando...'; 
            bs.disabled = true;
            if(window.lucide) window.lucide.createIcons(); 
            
            try { 
                const inputUser = document.getElementById('login-username');
                const rawUser = inputUser.value.trim().toLowerCase();
                const pass = document.getElementById('login-password').value;
                
                let finalEmail = '';
                let displayUsername = rawUser;

                if (rawUser.includes('@')) {
                    finalEmail = rawUser;
                    displayUsername = rawUser.split('@')[0];
                } else {
                    const dirRef = doc(db, "directorio_login", rawUser);
                    const dirSnap = await getDoc(dirRef);

                    if (dirSnap.exists()) {
                        finalEmail = dirSnap.data().email;
                        displayUsername = dirSnap.data().username;
                    } else {
                        finalEmail = rawUser + '@raspadillas.com';
                    }
                }
                
                await login(finalEmail, pass); 
                saveAccount(finalEmail, displayUsername, pass);

                setTimeout(() => { bs.innerHTML = ot; bs.disabled = false; }, 1000); 
            } catch (err) { 
                console.error("Error de autenticación:", err);
                
                if (err.message === "CUENTA_ELIMINADA" || err.message === "CUENTA_DESACTIVADA") {
                    document.getElementById('login-error').classList.add('hidden');
                    if(window.mostrarAlerta) window.mostrarAlerta('Acceso Denegado', 'Esta cuenta ha sido deshabilitada o eliminada permanentemente.', 'red');
                } else {
                    document.getElementById('login-error').classList.remove('hidden'); 
                }
                
                bs.innerHTML = ot; 
                bs.disabled = false; 
                if(window.lucide) window.lucide.createIcons(); 
            }
        });
    }
    
    const hL = async () => { 
        try { 
            await logout(); 
            if(lf) lf.reset(); 
            if(bs) { bs.innerHTML = 'Ingresar al Sistema'; bs.disabled = false; } 
            if(window.switchView) window.switchView('ventas'); 
        } catch (e) { 
            console.error("Error cerrando sesión:", e); 
        } 
    };
    
    document.getElementById('btn-logout-desktop')?.addEventListener('click', hL); 
    document.getElementById('btn-logout-mobile')?.addEventListener('click', hL);
});
